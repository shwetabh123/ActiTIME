package generic;

public interface IAutoConst {
	String CHROME_KEY="webdriver.chrome.driver";
	String CHROME_VALUE="./driver/chromedriver.exe";
	
	String XLPATH="./data/input.xlsx";
}


