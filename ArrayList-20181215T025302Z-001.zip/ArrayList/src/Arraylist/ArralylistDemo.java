
//GENERIC


package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArralylistDemo {
	
	public static void main(String[] args) {

			
			Employee e=new Employee();
			
			fish f =new fish("breed");
			
			Car c=new Car();
		

				//Employee specific arraylist 
			
			ArrayList <Employee>lst =new ArrayList<Employee>();

				
				lst.add(e);
				
			//	lst.add(f);// cant add fish
				
				//lst.add(c);//cant add car
				
				Iterator itr=lst.iterator();
				
				
				while(itr.hasNext())
				{
					
					
						System.out.println(e);
					}
					//Iterator itr1=lst.iterator();
					
				
					/*else if ( itr.next() instanceof fish)
					
					{
						fish  f1=(fish)itr.next();
						
						System.out.println(f1.breed);
							
						
					}
				else if ( itr.next() instanceof Car)
					
					{
						Car  c1=(Car)itr.next();
						
						System.out.println(c1.brand);
							
						
					}
					*/
						}

	}

	