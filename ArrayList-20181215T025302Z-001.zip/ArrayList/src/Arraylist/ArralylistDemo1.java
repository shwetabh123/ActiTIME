package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArralylistDemo1 {
	public static void main(String[] args) {
		
			ArrayList lst=new ArrayList();
			
			lst.add("Ravi");
			lst.add("Anu");
			
			lst.add("Jspiders");
			
			lst.add("Ram");
			System.out.println("Elements added are");
			
			for(Object obj: lst)
			{
				String st=(String)obj;
				System.out.println(st);
				
			}
			
			
			System.out.println("Size of arraylist before "+ lst.size());
			
			Iterator itr=lst.iterator();
			
			while(itr.hasNext())
				
			{
				
				if((itr.next()).equals("Anu"))
				
				itr.remove();
			}
			

			System.out.println("arraylist after deleting an element ");
	
			
for ( Object obj: lst)
{
	
	String s=(String )obj;
			
			System.out.println(s);
			
}
System.out.println("Size of arraylist after deleting element "+ lst.size());
		}

	}

