package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArralylistDemo2 {


		public static void main(String[] args) {
			
				ArrayList lst1=new ArrayList();

				ArrayList lst2=new ArrayList();
				
				lst1.add("A");
				lst1.add("B");
				
				lst1.add("C");
				
				lst1.add("D");
				lst2.add("E");
				lst2.add("F");
				
				lst2.add("G");
				
				lst2.add("H");
			
				lst1.addAll(lst2);
				
				Iterator itr=lst1.iterator();
				
				/*for(Object obj: lst1)
				{
					String st=(String)obj;
					System.out.println(st);
					
				}*/
				
				
				while(itr.hasNext())
				{
					
					String st=(String)itr.next();
					System.out.println(st);
					
					
				}
				
				

      

				

				
				
				
				
				
				
			}

		}

