package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArraylistDemo {
	
	
	public static void main(String[] args) {
	
		ArrayList lst=new ArrayList();
		
		lst.add("Ravi");
		lst.add("Anu");
		
		lst.add("Jspiders");
		
		lst.add("Ram");
		
		for(Object obj: lst)
		{
			
			String st=(String)obj;
			System.out.println(st);
			
		}
		
		Iterator itr=lst.iterator();
		
		while(itr.hasNext())
			
		{
			
			String s =(String)itr.next();
			System.out.println(s);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
