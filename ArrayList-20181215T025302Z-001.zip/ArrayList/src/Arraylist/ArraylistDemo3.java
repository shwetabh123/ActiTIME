package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArraylistDemo3 {

	public static void main(String[] args) {

		
		Student s1=new Student("Shwetabh",15.00);
		
		Student s2=new Student("Shwetabh1",25.00);
		Student s3=new Student("Shwetabh2",35.00);

		Student s4=new Student("Shwetabh3",45.00);
			
		ArrayList lst1=new ArrayList();

			
			lst1.add(s1);
			lst1.add(s2);
			lst1.add(s3);
			
			lst1.add(s4);
			
			
			
			
			Iterator itr=lst1.iterator();
			
			
			while(itr.hasNext())
			{
				Student s=(Student)itr.next();
				
				
				System.out.println(s.name+"  "+s.percentage);
			}
			
					}

	}

	
	
