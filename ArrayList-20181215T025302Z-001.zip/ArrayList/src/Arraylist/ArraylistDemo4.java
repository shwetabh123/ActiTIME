package Arraylist;

import java.util.ArrayList;
import java.util.Iterator;



public class ArraylistDemo4 {
	
	
	//NON GENERIC Demo
	
public static void main(String[] args) {

		
		Employee e=new Employee();
		
		fish f =new fish("breed");
		
		Car c=new Car();
	

					
		ArrayList lst=new ArrayList();

			
			lst.add(e);
			lst.add(f);
			lst.add(c);
			
			Iterator itr=lst.iterator();
			
			
			while(itr.hasNext())
			{
				if(itr.next() instanceof Employee){
					Employee e1 =(Employee)itr.next();
					
					System.out.println(e1.name);
				}
				//Iterator itr1=lst.iterator();
				
			
				else if ( itr.next() instanceof fish)
				
				{
					fish  f1=(fish)itr.next();
					
					System.out.println(f1.breed);
						
					
				}
			else if ( itr.next() instanceof Car)
				
				{
					Car  c1=(Car)itr.next();
					
					System.out.println(c1.brand);
						
					
				}
				
					}

}

}


