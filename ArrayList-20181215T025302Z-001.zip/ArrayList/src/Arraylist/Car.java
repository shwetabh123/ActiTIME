package Arraylist;

public class Car {
	
	String brand;
	
	
	/*
	public Car(String brand)
	{
		
		this.brand=brand;
	}
	
	
*/
}
