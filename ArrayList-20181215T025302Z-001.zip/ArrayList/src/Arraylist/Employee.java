package Arraylist;

public class Employee {
	String name;
	
	
	/*public Employee( String name){
		
		this.name=name;
		
	}
	*/

}
