package Arraylist;

public class Student {
	
	String name;
	double percentage;
	
	public Student( String name,double percentage)
	{
		this.name=name;
		this.percentage=percentage;
		
	}
	
	
	

}
