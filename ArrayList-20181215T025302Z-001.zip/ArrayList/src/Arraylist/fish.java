package Arraylist;

public class fish {
	String breed;
	fish(String breed){
		
	
	this.breed=breed;
	/*
	
	public fish(String breed)
	{
		
		this.breed=breed;
		
	}
*/
}}
