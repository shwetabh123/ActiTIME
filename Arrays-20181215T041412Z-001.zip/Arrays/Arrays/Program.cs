﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
            static void Main(String[] args)
            {

            Console.Write("Enter number of elements");

            int n= Int32.Parse(Console.ReadLine());
            int[] arr = new int[n];
        

            string[] s = Console.ReadLine().Split(' ');


            Console.Write("After reverse ");

            Array.Reverse(s);

            foreach (var num in s)
            {
                Console.Write($"{num} ");
            }

        }
        }

    }

