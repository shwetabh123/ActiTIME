//HAS A RELATIONSHIP
public class Car {
	
	double price;
	String color;
	
	Musicsystem ms;
	
	//Musicsystem ms=new Musicsystem();//creating ref variable
	
	void drive()
	{
	
		System.out.println("Car is driven");
		
	}
	
	
	

}
