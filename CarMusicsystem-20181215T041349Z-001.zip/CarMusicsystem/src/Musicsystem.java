
public class Musicsystem {
	
	
	String brand;
	String capacity;
	Speakers sp;
	void playmusic()
	
	
	{
		
		System.out.println("Music is played");
		
	}
	
	
	

}
