
public class Speakers {

	
	int volume;
	
	
	
	
	
}
