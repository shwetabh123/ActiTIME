
public class Tester  {
	
	
	public static void main ( String[] args)
	
	{
		
		
		Car c =new Car();
		
		c.color="Red";
		c.price=100.00;
				
		System.out.println(c.color);
		System.out.println(c.price);
			
		
		//Print  properties ( i.e. brand ) of MusicsystemClass ( Has a relationship with Car class)

	   c.ms=new Musicsystem();//creating ref variable
			
			
			
		c.ms.brand="jbl";
		
		String s=c.ms.brand;
		
		
		System.out.println(c.ms.brand);
		System.out.println(s);
		
		
		
		//Print speaker
		
		//Print  properties ( i.e. speaker) of SpeakerClass ( Speaker Has a relationship with Musicsystem class)

		
		c.ms.sp=new Speakers();
		
		
		c.ms.sp.volume=4;
		
		int v=c.ms.sp.volume;
		
		System.out.println(v);
		
		
		
	
	}
}
