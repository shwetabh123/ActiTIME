package abstractclasss;

public abstract class A {

	
	int i ;
	int j;

	
	public A( int i,int j)
	{
		this.i=i;
		this.j=j;
		
		//System.out.println("The sum is " +(this.i+this.j));
		
	}
	
abstract void  sum();

/*
int sum(int i , int j )
{
	int result;
	result=i+ j;
	
	System.out.println(result);

return result;
}
*/
	
}
