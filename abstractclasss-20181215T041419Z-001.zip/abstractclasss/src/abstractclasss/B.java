package abstractclasss;

public class B extends A {
	
	int k;
	
	public B(int i,int j,int k)
	{
		
		super(i,j);
		this.k=k;
		
		
		//System.out.println("The sum is " +(this.i+this.j+this.k));
		
		
	}
	
	void sum( )
	
		
	{
		System.out.println(i+j+k);
		
		/*int result;
		
		result=i+j+k;
		
		System.out.println(result);
	
	return result;*/
	}

	
	
	

}
