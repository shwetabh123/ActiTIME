package abstractclasss;

import abstractclasss.A;
import abstractclasss.B;
import abstractclasss.*;

public class C {

	
	public static void main(String[] args) 
	
	{
		
		
		
			
		/*	B b=new B(2,3,4);//initialize derived class constructor
			


			b.sum();;//---o/p is 9
			
			*/

		
		
/*		B b=new B(4,5,6);//initialize derived class constructor
		


		b.sum();----------o/p is 15*/
		
		
	     
			
          A a=new B (10,20,30); //PRCO
		
              a.sum();
		   
		

              
			
			//******************
			
	/*		A a=new B(10,4,5);//PRCO
			
		
			a.sum(10,15);//------------o/p is 25
			*/
			
			
			/*
			System.out.println(a.sum(11,9));
			
			
			System.out.println(a.i);
			
			System.out.println(a.j);
			*/
			//System.out.println(a.k);
			
			
			
			
		}
	}
